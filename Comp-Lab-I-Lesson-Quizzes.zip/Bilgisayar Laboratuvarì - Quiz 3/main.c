
//Quiz 03

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int islem;
    float basbakiye=1000,istenenpara,sonbakiye;

    printf("Bakiyeniz: %.2f\n\n",basbakiye);
    printf("****ISLEMLER****\n");
    printf("1. Para Cekme\n");
    printf("2. Para Yatirma\n");
    printf("3. Bakiye Kontrolu\n");
    printf("4. Kart Iade\n");
    printf("Her Islem Icin 5 Lira Ucret Kesilmektedir.\n");
    printf("Isleminizi Seciniz: ");
    scanf("%d",&islem);

    switch(islem) {
    case 1:
       printf("Bakiyeniz: %.2f\n",basbakiye-5);
       printf("Cekmek Istediginiz Tutari Giriniz: ",istenenpara);
       scanf("%f",&istenenpara);
       if(istenenpara+5>basbakiye)
        printf("Yetersiz Bakiye. Lutfen Kartinizi Geri Aliniz.");
       else
        printf("Yeni Bakiyeniz: %.2f",basbakiye-istenenpara-5);
       break;
    case 2:
        printf("Bakiyeniz: %.2f\n",basbakiye-5);
        printf("Yatirmak Istediginiz Tutari Giriniz: ");
        scanf("%f",&istenenpara);
        printf("Yeni Bakiyeniz: %.2f",basbakiye+istenenpara-5);
        break;
    case 3:
        printf("Bakiyeniz: %.2f",basbakiye-5);
        break;
    case 4:
        printf("Kartinizi Almayi Unutmayin.");
        break;
    default:
        sonbakiye=basbakiye-5;
        printf("Gecersiz Islem. Lutfen Kartinizi Geri Aliniz.");
    }
    return 0;
}
