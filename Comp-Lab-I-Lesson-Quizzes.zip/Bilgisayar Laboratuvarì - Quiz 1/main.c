//Goksel Okandan
//210201058
//01

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float dikkenar1;
    float dikkenar2;
    float hipotenus;
    float cevre;
    float alan;

    printf("Birinci Dik Kenari Giriniz: ");
    scanf("%f",&dikkenar1);
    printf("Ikinci Dik Kenari Giriniz: ");
    scanf("%f",&dikkenar2);

    hipotenus=sqrt((dikkenar1*dikkenar1)+(dikkenar2*dikkenar2));
    cevre=dikkenar1+dikkenar2+hipotenus;
    alan=(dikkenar1*dikkenar2)/2;

    printf("\nHipotenus: %.2f\n",hipotenus);
    printf("Cevre: %.2f\n",cevre);
    printf("Alan: %.2f",alan);
    return 0;
}
